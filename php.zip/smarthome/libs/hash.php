<?php

class hash{

	/*
	*	@param string $algo The algorith to hash data (md5, sha1 etc)
	*	@param string $data The data
	*	@param string $salt The key
	*	@return string hashed data
	*/

	public static function create($algo, $data, $salt){

		$context = hash_init($algo,HASH_HMAC,$salt);
		hash_update($context, $data);

		return hash_final($context);
	}
}
