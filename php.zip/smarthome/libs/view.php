<?php

class view{

	function __construct(){
	}

	public function render($name, $noInclude = true){
		require 'views/beginHTML.php';
		if($noInclude){
			require 'views/side_menu.php';
			require 'views/top_menu.php';
		}
		require 'views/'.$name.'.php';
		require 'views/endHTML.php';
	}
}
