<?php

class bootstrap {

	function __construct() {

		$url = isset($_GET['url']) ? $_GET['url'] : null;
		$url = rtrim($url, '/');
		$url = filter_var($url, FILTER_SANITIZE_URL);
		$url = explode('/', $url);

		//Take all method parameters if they exist
		$parameters = $_REQUEST;
		unset($parameters['url']);
		
		if (empty($url[0])) {
			$controller = new home();
			$controller->loadModel('home');
			$controller->index();
			return false;
		}

		$file = 'controllers/' . strtolower($url[0]) . '.php';
		if (file_exists($file)) {
			require $file;
		} else {
			$this->notFound();
		}
		
		$urlClass = strtolower($url[0]);
		$controller = new $urlClass;
		$controller->loadModel($url[0]);

		// calling methods
		if (isset($url[1])) {
			if (method_exists($controller, $url[1])) {
				if(isset($parameters)){
					$controller->{$url[1]}($parameters);
				}else{
					$controller->{$url[1]}();
				}
			} else {
				$this->notFound();
			}
		} else {
			$controller->index($parameters);
		}
	}

	function notFound() {
		$controller = new notfound();
		$controller->loadModel('notfound');
		$controller->index();
		die;
	}
}
