<?php

class sendsms{

	public $From;
	public $Message;
	public $toNumbers = array();

	public function __construct($from,$message){
		$this->From = $from;
		$this->Message = $message;
	}

	// Send SMS to all telephones in $toNumbers
	public function sendSMS($toNumbers){

		$url = "https://rest.nexmo.com/sms/json";

		foreach ($toNumbers as $key => $value) {

				$data = array(
					'api_key' => 'a3f47b1a',
					'api_secret' => '80e8dac04e6e4a89',
					'to' => $value["Telephone"],
					'from' => 'Website',
					'text' => $this->Message
				);

				self::httpPost($url, $data);
		}

		/*******************************************
		/** Send SMS logic code in here. Code will
		/** differ depending the api used.
		/*******************************************/

		return 'success';
	}
	
	function httpPost()
	{
		$url = 'https://rest.nexmo.com/sms/json';
		$data = array(
						"api_key" => "0d9f607f",
						"api_secret" => "jQp4BTkD9YxfEhVF",
						"to" => "27620969176",
						"From" => "Public Service",
						"text" => "Testing message"
					);
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		$response = curl_exec($curl);
		curl_close($curl);
		return $response;
	}

	function httpPost($url, $data){
    $curl = curl_init($url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($curl);
    curl_close($curl);
	}

}
