<?php

class randomstring{

	public static function create(){
		$length = 5;
		return substr(str_shuffle(md5(time())),0,$length);
	}
}
