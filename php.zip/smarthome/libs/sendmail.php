<?php

class sendmail{

	public $From;
	public $Subject;
	public $Message;
	public $Headers;
	public $toEmails = array();

	public function __construct($subject, $from = 'nonreply@studentportal.co.za'){
		$this->From = $from;
		$this->Subject = $subject;

		$this->Headers = "From: " . $this->From . "\r\n";
		$this->Headers .= "Reply-To: ". $this->From . "\r\n";
		$this->Headers .= "MIME-Version: 1.0\r\n";
		$this->Headers .= "X-Priority: 1 (Highest)\n";
		$this->Headers .= "X-MSMail-Priority: High\n";
		$this->Headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
	}

	// Take PersonID, then search for the email addresses of a Person
	// Then initialize toEmails with the email addresses of the Person
	// With PersonID
	public function setToEmailsByPersonID($toPersonID){
		$user = new user($toPersonID);
		$emails = json_decode($user->preferredEmails(),true);

		foreach ($emails as $key => $value) {
			array_push($this->toEmails, $value['EmailAddress']);
		}
	}

	//Initialize toEmails with raw array of emails
	public function setToEmails($toEmails){
		array_push($this->toEmails, $toEmails);
	}

	// Finally, after setting all the varaibles provide message data,
	// Message to be read by the recipient and send email.
	public function sendGeneral($bodyHeading , $bodyHeadingMessage , $bodyMainMessage){

		$org = new org();
		$orgData = $org->GetOrg();

		include('mails/general.php');

		$this->Message = $message;

		foreach ($this->toEmails as $key => $email) {
			@mail($email, $this->Subject , $this->Message, $this->Headers);
		}
	}

	// send email to multiple users
	public function sendGeneralToEmails($bodyHeading , $bodyHeadingMessage , $bodyMainMessage, $toEmails){

		$org = new org();
		$orgData = $org->GetOrg();

		include('mails/general.php');
		$this->Message = $message;

		foreach ($toEmails as $key => $value) {
			@mail($value['EmailAddress'], $this->Subject , $this->Message, $this->Headers);
		}
	}
	
	// send email to one user
	public function sendGeneralToEmail($bodyHeading , $bodyHeadingMessage , $bodyMainMessage, $toEmail){

		$org = new org();
		$orgData = $org->GetOrg();

		include('mails/general.php');
		
		$this->Message = $message;

		@mail($toEmail, $this->Subject , $this->Message, $this->Headers);
	}

	// Finally, after setting all the varaibles provide message data,
	// Message to be read by the recipient and send email.
	public function sendPasswordRecovery($bodyHeading , $bodyHeadingMessage , $bodyMainMessage, $Key){

		$org = new org();
		$orgData = $org->GetOrg();

		include('mails/recoverPassword.php');

		$this->Message = $message;

		foreach ($this->toEmails as $key => $email) {
			@mail($email, $this->Subject , $this->Message, $this->Headers);
		}
	}
}
