<?php

class database extends PDO{

	public function __construct(){
		try{
				parent::__construct(DB_TYPE.':host='.DB_HOST.';dbname='.DB_NAME, DB_USER,DB_PASS);
    }catch (PDOException $e){
			if($e->getCode() == '2002'){
				 echo "Connection refused.<br/>
				 			 Your ".strtoupper(DB_TYPE)." database is not running.";
			}else{
				 echo $e->getMessage();
			}
      die;
    }
	}
}
