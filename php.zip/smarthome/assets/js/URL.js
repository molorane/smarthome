var current_path = window.location.href;

var res = current_path.split("/");

var path = res[0]+'//'+res[2]+'/'+res[3]+'/';

// replace above line with below line when online
// var path = res[0]+'//'+res[2]+'/';

var queryDict = {};
location.search.substr(1).split("&").forEach(function(item) {
    queryDict[item.split("=")[0]] = item.split("=")[1]
});


function notify(success, _title, message){
	if(success == 1){
		new PNotify({title: _title,text: message,type: 'success'});
	}else{
		new PNotify({title: _title,text: message,type: 'danger'});
	}
}