<?php
	class appliances extends maincontroller{
		
		function __construct(){

			parent::__construct();

			$this->isLoggedIn();
			$this->LoggedInUser = session::get('UserName');
			$this->view->controller = "connected_device";
			self::pnotifyScripts();	
			
			$this->view->domain_url = URL_DIRECTORY;
		}

	function index(){
		$this->view->title = "Smart Home";
		$this->view->page = "Appliances";
		$this->view->action = "light";
		$this->view->render('appliances/index');
	}

	function dashboard(){
		$this->index();
	}

	function home(){
		$this->index();
	}
	
	function appliances($page, $action){
		
		$this->view->angularjs = array(
									URL_DIRECTORY."views/appliances/js/connected_devices.js",
									JS_DIRECTORY.'angular/smartHomeService.js');
		
		$this->view->title = "Smart Home";
		$this->view->page = $page;
		$this->view->action = $action;
		$this->view->render('appliances/devices');
	}
	
	function app($parameters){
		
		if(!empty($parameters['app_id'])){
			
			$app = json_decode($this->model->GetAppliance($parameters['app_id']),true);
			
			if(!empty($app)){
				$this->appliances($app[0]['appliance'], $app[0]['appliance']);
			}else{
				$this->nodata();
			}
		}else{
			$this->invalidParameters();
		}
		
	}
	
	function pir($parameters){
		
		if(empty($parameters['pir_id'])){
			$this->view->angularjs = array(
										URL_DIRECTORY."views/appliances/pir/js/pir.js",
										JS_DIRECTORY.'angular/smartHomeService.js');
			
			$this->view->title = "Smart Home";
			$this->view->page = "Motion Sensor";
			$this->view->action = "Motion Sensor";
			$this->view->render('appliances/pir/index');
		}else{
			$isPIR = json_decode($this->model->isPIR($parameters['pir_id']),true);
			if(!empty($isPIR)){
				$this->view->angularjs = array(
										URL_DIRECTORY."views/appliances/pir/nearByBulbs/js/addPIRBulb.js",
										JS_DIRECTORY.'angular/smartHomeService.js');
			
				$this->view->title = "Smart Home";
				$this->view->page = "Motion Sensor - Bulbs";
				$this->view->action = "Motion Sensor - Bulbs";
				$this->view->render('appliances/pir/nearByBulbs/index');
			}else{
				$this->nodata();
			}
		}
	}
	
	
	// Get all devices with device_id =device_id 
	function AllDevices(){
		$app_id = $_POST['app_id'];
		echo $this->model->AllDevices($app_id); die;
	}
	
	// Get allConnectedBulbs
	function allConnectedBulbs(){
		echo $this->model->allConnectedBulbs(); die;
	}
	
	function allPIRBulbs(){
		$pir_id = $_POST['pir_id'];
		echo $this->model->allPIRBulbs($pir_id); die;
	}
	
	function addPIRBulb(){
		$pir_id = $_POST['pir_id'];
		$conn_d_id = $_POST['conn_d_id'];
		echo $this->model->addPIRBulb($pir_id ,$conn_d_id); die;
	}
	
	function deletePIRBulb(){
		$conn_d_id = $_POST['conn_d_id'];
		$pir_id = $_POST['pir_id'];
		echo $this->model->deletePIRBulb($conn_d_id, $pir_id); die;
	}
}
