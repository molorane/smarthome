<?php
	class home extends maincontroller{

		function __construct(){
			parent::__construct();
			$this->isLoggedIn();
			$this->LoggedInUser = session::get('UserName');
			$this->view->controller = "connected_device";
			self::fusionChartScripts();
			self::pnotifyScripts();
		}

	function index(){
		
		$this->view->angularjs = array(
									URL_DIRECTORY.'views/home/js/home.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
					
		$this->view->title = "Smart Home";
		$this->view->page = "Dashboard";
		$this->view->action = "reports";
		$this->view->render('home/index');
	}


	function dashboard(){
		$this->index();
	}

	function home(){
		$this->index();
	}
	
	function getUsage(){
		$startDate = '2018-01-01';
		$endDate = '2018-12-30';
		echo $this->model->getUsage($startDate, $endDate); die;
	}
}
