<?php

class connected_devices extends maincontroller{

	function __construct(){
		parent::__construct();
		$this->isLoggedIn();
		$this->LoggedInUser = session::get('UserName');
		$this->view->controller = "connected_device";
		self::pnotifyScripts();
		
		$this->view->domain_url = URL_DIRECTORY;
	}

	function index(){
		$this->view->angularjs = array(
									URL_DIRECTORY.'views/connected_devices/js/connected_devices.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
					
		$this->view->title = "Smart Home";
		$this->view->page = "Connected Devices";
		$this->view->action = "light";
		$this->view->render('connected_devices/index');
	}

	function dashboard(){
		$this->index();
	}

	function home(){
		$this->index();
	}
	
	// Add Appliance
	function AllConnectedDevices(){
		echo $this->model->AllConnectedDevices();
		die;
	}
	
	// get Connected Device
	function getConnectedDevice(){
		$conn_device_id = $_POST['device_id'];
		echo $this->model->getConnectedDevice($conn_device_id);
		die;
	}
	
	// get Device
	function getDevice($conn_device_id){
		return $this->model->getConnectedDevice($conn_device_id);
	}
	
	// get DeviceActivity
	function getDeviceActivity(){
		$conn_device_id = $_POST['device_id'];
		echo $this->model->getDeviceActivity($conn_device_id);
		die;
	}
	
	// onStatusChange
	function onStatusChange(){
		$conn_device_id = $_POST['device_id'];
		$device_type = $_POST['device_type'];
		$dstatus = $_POST['dstatus'];
		$this->model->onStatusChange($this->LoggedInUser, $conn_device_id, $device_type , $dstatus);
		die;
	}
	
	// onModeChange
	function onModeChange(){
		$conn_device_id = $_POST['device_id'];
		$device_type = $_POST['device_type'];
		$dstatus = $_POST['dstatus'];
		$this->model->onModeChange($this->LoggedInUser, $conn_device_id, $device_type, $dstatus);
		die;
	}
	
	// setAutoOnTime
	function setAutoOnTime(){
		$conn_device_id = $_POST['device_id'];
		$device_type = $_POST['device_type'];
		$auto_time = $_POST['auto_time'];
		$this->model->setAutoOnTime($this->LoggedInUser, $conn_device_id, $device_type, $auto_time);
		die;
	}
	
	// setAutoOffTime
	function setAutoOffTime(){
		$conn_device_id = $_POST['device_id'];
		$device_type = $_POST['device_type'];
		$auto_time = $_POST['auto_time'];
		$this->model->setAutoOffTime($this->LoggedInUser, $conn_device_id, $device_type, $auto_time);
		die;
	}
	
	function device($parameters){
		
		if(!empty($parameters['device_id'])){
			$device = json_decode($this->getDevice($parameters['device_id']),true);
			if(count($device) > 0){
				array_push($this->view->css,
							CSS_DIRECTORY.'bootstrap-datetimepicker.min.css');
							
				array_push($this->view->js,
							JS_DIRECTORY.'bootstrap-datetimepicker.js',
							JS_DIRECTORY.'customDatePicker.js');
				
				$this->view->angularjs = array(
									URL_DIRECTORY.'views/connected_devices/device/js/device.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
				
				$this->view->title = "Smart Home";
				$this->view->page = "Connected Device";
				$this->view->action = "Device";
				$this->view->render('connected_devices/device/index');
			}else{
				$this->invalidParameters();
			}
		}else{
			$this->invalidParameters();
		}
	}
	
	function editDevice($parameters){
		$this->isUserAllowed(Session::get('UserRole'),array("Admin"));
		if(!empty($parameters['device_id'])){
			$device = json_decode($this->getDevice($parameters['device_id']),true);
			if(count($device) > 0){
				
				$this->view->angularjs = array(
									URL_DIRECTORY.'views/connected_devices/editDevice/js/editDevice.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
				
				$this->view->title = "Smart Home";
				$this->view->page = "Connected Device";
				$this->view->action = "Edit Device";
				$this->view->render('connected_devices/editDevice/index');
			}else{
				$this->invalidParameters();
			}
		}else{
			$this->invalidParameters();
		}
	}
	
	function appConsumption($parameters){
		
		if(!empty($parameters['device_id'])){
			
			$app = json_decode($this->model->getDeviceActivity($parameters['device_id']),true);
			
			if(!empty($app)){
				
				$this->view->angularjs = array(
									URL_DIRECTORY.'views/connected_devices/appConsumption/js/appConsumption.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
				
				$this->view->title = "Smart Home";
				$this->view->page = "Device Usage";
				$this->view->action = "Edit Device";
				$this->view->render('connected_devices/appConsumption/index');
			}else{
				$this->nodata();
			}
		}else{
			$this->invalidParameters();
		}
		
	}
	
	// edit Connected Device
	function editConnectedDevice(){
		if($this->isAuthorised(Session::get('UserRole'),array("Admin"))){
			$connDeviceID = $_POST['connDeviceID'];
			$ddlAppliance = $_POST['ddlAppliance'];
			$ddlLevel = $_POST['ddlLevel'];
			$ddlLocation = $_POST['ddlLocation'];
			$txtDeviceName = $_POST['txtDeviceName'];
			$txtWatts = $_POST['txtWatts'];
			$this->model->editConnectedDevice($connDeviceID, $ddlAppliance, $ddlLevel, $ddlLocation,$txtDeviceName,$txtWatts);
		}else{
			self::GenericResponse(2,"You are not authorized to perform this action. Only an administrator can edit a device.
			If you think you have a right to perform this action but denied, please consult Mr Molorane");
		}
		die;
	}
	
	// delete Appliance
	function deleteAppliance(){
		if($this->isAuthorised(Session::get('UserRole'),array("Admin"))){
			$conn_d_id = $_POST['conn_d_id'];
			$this->model->deleteAppliance($conn_d_id);
		}else{
			self::GenericResponse(2,"You are not authorized to perform this action. Only an administrator can delete a device.
			If you think you have a right to perform this action but denied, please consult Mr Molorane");
		}
		die;
	}
	
	// delete DeviceLogg
	function deleteDeviceLog(){
		if($this->isAuthorised(Session::get('UserRole'),array("Admin"))){
			$loggID = $_POST['loggID'];
			$this->model->deleteDeviceLog($loggID);
		}else{
			self::GenericResponse(2,"You are not authorized to perform this action. Only an administrator can delete a device.
			If you think you have a right to perform this action but denied, please consult Mr Molorane");
		}
		die;
	}
	
	// emptyLog
	function emptyLog(){
		if($this->isAuthorised(Session::get('UserRole'),array("Admin"))){
			$device_id = $_POST['device_id'];
			$this->model->emptyLog($device_id);
		}else{
			self::GenericResponse(2,"You are not authorized to perform this action. Only an administrator can delete a device.
			If you think you have a right to perform this action but denied, please consult Mr Molorane");
		}
		die;
	}
	
	/**
	 *  Macros Commands
	 *	macrosStatus
	 * @param array(ints) $device_ids  is a list of all devices to either turn on / off.
	 */
	 
	function macrosTurnOn(){
		$device_ids = $_POST['device_ids'];
		echo $this->model->macrosTurnOn($this->LoggedInUser,$device_ids);
		die;
	}
	
	function macrosTurnOff(){
		$device_ids = $_POST['device_ids'];
		echo $this->model->macrosTurnOff($this->LoggedInUser,$device_ids);
		die;
	}
}
