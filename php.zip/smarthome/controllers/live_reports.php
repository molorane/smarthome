<?php
	class live_reports extends maincontroller{

	function __construct(){
		parent::__construct();
		$this->isLoggedIn();
		$this->LoggedInUser = session::get('UserName');
		$this->view->controller = "connected_device";
		self::fusionChartScripts();
		self::pnotifyScripts();
	}

	function index(){
		$this->view->angularjs = array(
									JS_DIRECTORY.'gauge.min.js',
									URL_DIRECTORY.'views/reports/live/js/live.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
					
		$this->view->title = "Smart Home";
		$this->view->page = "Live Reporting";
		$this->view->action = "reports";
		$this->view->render('reports/live/index');
	}

	function dashboard(){
		$this->index();
	}

	function home(){
		$this->index();
	}
	
	function getLiveAmps(){
		
		$data = json_decode($this->model->getLiveAmpsDB(), true);
		
		$lvTime = $data['liveTime'];
		$lvAmps = $data['liveValue'] * 100;
		$expValue = $data['expValue'] * 100;
		
		echo  "&label=".$lvTime."&value=".$lvAmps."|".$expValue;
	}
	
	function getLiveRaw(){
		
		$data = json_decode($this->model->getLiveAmpsDB(), true);
		
		$lvTime = $data['liveTime'];
		$lvAmps = $data['liveRaw'];
		$expValue = 510;
		
		echo  "&label=".$lvTime."&value=".$lvAmps."|".$expValue;
	}
}
