<?php


class profile extends maincontroller{

	function __construct(){
		parent::__construct();
		
		$this->isLoggedIn();
		$this->LoggedInUser = session::get('UserName');
		
		self::pnotifyScripts();
		array_push($this->view->js,
					JS_DIRECTORY.'jquery.form.js?v=1.1',
					URL_DIRECTORY.'views/profile/js/upload_profile_picture.js?v=1.1');
		
		$this->view->angularjs = array(
									URL_DIRECTORY.'views/profile/js/profile.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
	}

	function index(){				
		$this->view->title = "Smart Home";
		$this->view->page = "Profile";
		$this->view->errorCode = "Resource profile";
		$this->view->render('profile/index');
	}
	
	//Get all Boards
	function GetUserActivity(){
		echo $this->model->GetUserActivity($this->LoggedInUser);
		die;
	}
	
	function UploadProfilePicture(){
		$this->model->UploadProfilePicture($this->LoggedInUser);
		die;
	}
	
	// changePassword
	function changePassword(){
		$txtOldPassword = $_POST['txtOldPassword'];
		$txtNewPassword = $_POST['txtNewPassword'];
		$txtConfirmPassword = $_POST['txtConfirmPassword'];
		$this->model->changePassword($this->LoggedInUser,$txtOldPassword, $txtNewPassword, $txtConfirmPassword);
		die;
	}
	// changePin
	function changePin(){
		$txtNewPin = $_POST['txtNewPin'];
		$txtConfirmPin = $_POST['txtConfirmPin'];
		$this->model->changePin($this->LoggedInUser,$txtNewPin, $txtConfirmPin);
		die;
	}
}
