<?php
	class logout extends maincontroller{
		function __construct(){
			parent::__construct();
		}

		function index(){
			session::destroy();
			header('location: '.URL_DIRECTORY.'login');
			die;
		}
	}

?>
