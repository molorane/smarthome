<?php
	class login extends maincontroller{
		
		function __construct(){
			parent::__construct();
		}

		function index(){
			$LoggedIn = session::get('LoggedIn');
			if($LoggedIn == false){
				
				$host = explode('/', $_SERVER['REQUEST_URI']);
				$this->view->title = "Smart Home";
				$this->view->page = "Login";
				$this->view->action = "login";
				$this->view->render('login/index',false);
			}else{
				$host = explode('/', $_SERVER['REQUEST_URI']);
				header('location: home');
			}
		}
		
		function locked(){
			$this->view->status = "locked";
			$this->view->error = "Account locked";
			$this->view->title = "Smart Home";
			$this->view->page = "Login";
			$this->view->action = "login";
			$this->view->render('login/index',false);
		}
		
		function invalid(){
			$this->view->status = "invalid";
			$this->view->error = "Invalid credentials";
			$this->view->title = "Smart Home";
			$this->view->page = "Login";
			$this->view->action = "login";
			$this->view->render('login/index',false);
		}

		function run(){
			$this->model->run();
		}
	}
?>
