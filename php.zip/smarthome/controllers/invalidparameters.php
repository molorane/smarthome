<?php


class invalidparameters extends maincontroller{

	function __construct(){
		parent::__construct();
		$this->isLoggedIn();
	}

	function index(){
		$this->view->title = "Error 405";
		$this->view->page = "Invalid parameters";
		$this->view->msg = "Invalid parameters for the selected resource! Do not change the URL agrs";
		$this->view->errorCode = "Error 405";
		$this->view->render('invalidparameters/index',false);
	}
}
