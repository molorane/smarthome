<?php
	class settings extends maincontroller{

		function __construct(){

			parent::__construct();

			$this->isLoggedIn();
			$this->LoggedInUser = session::get('UserName');
			$this->isUserAllowed(Session::get('UserRole'),array("Admin"));
		}

	function index(){
		$this->view->title = "Smart Home";
		$this->view->page = "Configurations";
		$this->view->action = "settings";
		$this->view->render('settings/index');
	}

	/*****************************************************************
		Appliance Section
	******************************************************************/

	function appliances(){

		self::pnotifyScripts();
		$this->view->angularjs = array(
							URL_DIRECTORY.'views/settings/appliances/js/appliances.js?v=1.1',
							JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');

		$this->view->title = "Smart Home";
		$this->view->page = "Appliance Categories";
		$this->view->action = "Appliance";
		$this->view->render('settings/appliances/index');
	}

	// Add Appliance
	function AddAppliance(){
		$txtAppliance = $_POST['txtAppliance'];
		$this->model->AddAppliance($txtAppliance);
		die;
	}

	// Edit Appliance
	function EditAppliance(){
		$AppID = $_POST['AppID'];
		$txtAppliance = $_POST['txtAppliance'];
		$this->model->EditAppliance($AppID,$txtAppliance);
		die;
	}

	// Delete Appliance
	function DeleteAppliance(){
		$AppID = $_POST['AppID'];
		$this->model->DeleteAppliance($AppID);
		die;
	}

	//Get all Appliances
	function GetAllAppliances(){
		echo $this->model->AllAppliances();
		die;
	}

	function GetAllLocations(){
		echo $this->model->GetAllLocations();
		die;
	}

	//Get all Boards
	function GetAllBoards(){
		echo $this->model->GetAllBoards();
		die;
	}

	//Get all Boards
	function GetUnUsedPorts(){
		echo $this->model->GetUnUsedPorts();
		die;
	}

	/*****************************************************************
		Roles Section
	******************************************************************/

	function roles(){

		self::pnotifyScripts();
		$this->view->angularjs = array(
							URL_DIRECTORY.'views/settings/roles/js/roles.js',
							JS_DIRECTORY.'angular/smartHomeService.js');

		$this->view->title = "Smart Home";
		$this->view->page = "Roles";
		$this->view->action = "Role";
		$this->view->render('settings/roles/index');
	}

	// Add Role
	function AddRole(){
		$txtRole = $_POST['txtRole'];
		$this->model->AddRole($txtRole);
		die;
	}

	// Edit Role
	function EditRole(){
		$RoleID = $_POST['RoleID'];
		$txtRole = $_POST['txtRole'];
		$this->model->EditRole($RoleID,$txtRole);
		die;
	}

	// Delete Role
	function DeleteRole(){
		$RoleID = $_POST['RoleID'];
		$this->model->DeleteRole($RoleID);
		die;
	}

	//Get all Roles
	function GetAllRoles(){
		echo $this->model->AllRoles();
		die;
	}

	/*****************************************************************
		Accounts Section
	******************************************************************/

	function accounts(){

		self::pnotifyScripts();
		$this->view->angularjs = array(
							URL_DIRECTORY.'views/settings/accounts/js/accounts.js?v=1.1',
							JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');

		$this->view->title = "Smart Home";
		$this->view->page = "Accounts";
		$this->view->action = "Account";
		$this->view->render('settings/accounts/index');
	}


	function viewAccount($parameters){

		if(!empty($parameters['user_id'])){

			//$device = json_decode($this->getDevice($parameters['user_id']),true);

			if(true){

				self::pnotifyScripts();
				$this->view->angularjs = array(
									URL_DIRECTORY.'views/settings/accounts/viewAccount/js/editAccount.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');

				$this->view->title = "Smart Home";
				$this->view->page = "Connected Device";
				$this->view->action = "Edit Device";
				$this->view->render('settings/accounts/viewAccount/index');
			}else{
				$this->invalidParameters();
			}
		}else{
			$this->invalidParameters();
		}
	}


	// Add Account
	function AddAccount(){
		$Account = $_POST['Account'];
		$this->model->AddAccount($Account);
		die;
	}

	// Edit Acoount
	function EditAccount(){
		$AccountID = $_POST['AccountID'];
		$AccountValue = $_POST['AccountValue'];
		$this->model->EditAccount($AccountID,$AccountValue);
		die;
	}

	// Delete Acoount
	function DeleteAccount(){
		$AccountID = $_POST['AccountID'];
		$this->model->DeleteAccount($AccountID);
		die;
	}

	//Get all Acoounts
	function GetAllAccounts(){
		echo $this->model->AllAccounts();
		die;
	}

	// Add Account
	function newAccount(){

		self::pnotifyScripts();
		$this->view->angularjs = array(
							URL_DIRECTORY.'views/settings/accounts/newAccount/js/newAccount.js?v=1.1',
							JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');

		$this->view->title = "Smart Home";
		$this->view->page = "Accounts";
		$this->view->action = "New Account";
		$this->view->render('settings/accounts/newAccount/index');
	}

	//get User Account
	function getUserAccount(){
		$UserName = $_POST['UserName'];
		echo $this->model->getUserAccount($UserName);
		die;
	}

	// editUserAccount
	function editUserAccount(){
		$txtUserName = $_POST['txtUserName'];
		$ddlRole = $_POST['ddlRole'];
		$txtEmail = $_POST['txtEmail'];
		$chkIsAproved = $_POST['chkIsAproved'];
		$chkIsLocked = $_POST['chkIsLocked'];
		$this->model->editUserAccount($txtUserName,$ddlRole,$txtEmail,$chkIsAproved,$chkIsLocked);
		die;
	}

	// AddUserAccount
	function AddUserAccount(){
		$txtUserName = $_POST['txtUserName'];
		$ddlRole = $_POST['ddlRole'];
		$txtSurname = $_POST['txtSurname'];
		$txtFirstName = $_POST['txtFirstName'];
		$txtEmail = $_POST['txtEmail'];
		$chkIsAproved = $_POST['chkIsAproved'];
		$chkIsLocked = $_POST['chkIsLocked'];
		$txtPassword = $_POST['txtPassword'];
		$txtConfirmPassword = $_POST['txtConfirmPassword'];
		$this->model->AddUserAccount($txtUserName,$ddlRole,$txtSurname,$txtFirstName,$txtEmail,$chkIsAproved,$chkIsLocked,$txtPassword,$txtConfirmPassword);
		die;
	}


	/*****************************************************************
		Add device Section
	******************************************************************/

	function addDevice(){

		self::pnotifyScripts();
		$this->view->angularjs = array(
							URL_DIRECTORY.'views/settings/addDevice/js/addDevice.js?v=1.1',
							JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');

		$this->view->title = "Smart Home";
		$this->view->page = "Settings";
		$this->view->action = "Add New Appliance";
		$this->view->render('settings/addDevice/index');
	}

	// new Device
	function newDevice(){
		$ddlAppliance = $_POST['ddlAppliance'];
		$ddlLevel = $_POST['ddlLevel'];
		$ddlLocation = $_POST['ddlLocation'];
		$txtDeviceName = $_POST['txtDeviceName'];
		$ddlConnPort = $_POST['ddlConnPort'];
		$txtWatts = $_POST['txtWatts'];
		$this->model->newDevice($ddlAppliance,$ddlLevel,$ddlLocation,$txtDeviceName,$ddlConnPort,$txtWatts);
		die;
	}


	/*****************************************************************
		Connection Points Section
	******************************************************************/

	function ports(){

		self::pnotifyScripts();
		$this->view->angularjs = array(
							URL_DIRECTORY.'views/settings/ports/js/ports.js',
							JS_DIRECTORY.'angular/smartHomeService.js');

		$this->view->title = "Smart Home";
		$this->view->page = "Ports";
		$this->view->action = "Port";
		$this->view->render('settings/ports/index');
	}

	// Add Port
	function AddPort(){
		$port = $_POST['port'];
		$this->model->AddPort($connPort);
		die;
	}

	// Edit Port
	function EditPort(){
		$portID = $_POST['portID'];
		$port = $_POST['port'];
		$this->model->EditPort($portID,$port);
		die;
	}

	// Delete Port
	function DeletePort(){
		$portID = $_POST['portID'];
		$this->model->DeletePort($portID);
		die;
	}

	//Get all Roles
	function GetAllPorts(){
		echo $this->model->AllPorts();
		die;
	}


	/*****************************************************************
		General Section
	******************************************************************/

	function general(){

		self::pnotifyScripts();
		$this->view->angularjs = array(
							URL_DIRECTORY.'views/settings/general/js/general.js',
							JS_DIRECTORY.'angular/smartHomeService.js');

		$this->view->title = "Smart Home";
		$this->view->page = "General Settings";
		$this->view->action = "Port";
		$this->view->render('settings/general/index');
	}

	//Get Settings
	function GetSettings(){
		echo $this->model->GetSettings();
		die;
	}


	// save Settings
	function saveSettings(){
		$txtConsumption = $_POST['txtConsumption'];
		$txtEmail = $_POST['txtEmail'];
		$emailOnConsumption = $_POST['emailOnConsumption'];
		$emailOnAlarm = $_POST['emailOnAlarm'];
		$txtPhone = $_POST['txtPhone'];
		$phoneOnConsumption = $_POST['phoneOnConsumption'];
		$phoneOnAlarm = $_POST['phoneOnAlarm'];
		$txtDailyConsumption = $_POST['txtDailyConsumption'];
		$txtWeeklyConsumption = $_POST['txtWeeklyConsumption'];
		$txtMonthlyConsumption = $_POST['txtMonthlyConsumption'];
		$dailyActivities = $_POST['dailyActivities'];
		$this->model->saveSettings($txtConsumption,$txtEmail, $emailOnConsumption, $emailOnAlarm, $txtPhone, $phoneOnConsumption,
									$phoneOnAlarm, $txtDailyConsumption, $txtWeeklyConsumption, $txtMonthlyConsumption, $dailyActivities);
		die;
	}



	/*****************************************************************
		Rates Section - Electricity charge per kwh
	******************************************************************/

	function rates(){

		self::pnotifyScripts();
		$this->view->angularjs = array(
							URL_DIRECTORY.'views/settings/rates/js/rates.js?v=1.1',
							JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');

		$this->view->title = "Smart Home";
		$this->view->page = "Rates";
		$this->view->action = "Rates";
		$this->view->render('settings/rates/index');
	}

	// Add Rate
	function AddRate(){
		$txtRate = $_POST['txtRate'];
		$this->model->AddRate($txtRate);
		die;
	}

	// Edit Rate
	function EditRate(){
		$raID = $_POST['raID'];
		$txtRate = $_POST['txtRate'];
		$this->model->EditRate($raID,$txtRate);
		die;
	}

	// Delete Rate
	function DeleteRate(){
		$raID = $_POST['raID'];
		$this->model->DeleteRate($raID);
		die;
	}

	//Get All Rates
	function GetAllRates(){
		echo $this->model->AllRates();
		die;
	}


	/*****************************************************************
		Consumption Section - Electricity consumption
	******************************************************************/

	function consumption(){

		self::pnotifyScripts();
		$this->view->angularjs = array(
							URL_DIRECTORY.'views/settings/consumption/js/consumption.js?v=1.1',
							JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');

		$this->view->title = "Smart Home";
		$this->view->page = "Consumption";
		$this->view->action = "Consumption";
		$this->view->render('settings/consumption/index');
	}

	//Get Consumption
	function GetConsumption(){
		echo $this->model->GetConsumption();
		die;
	}


	/*****************************************************************
		Application Section
	******************************************************************/


	//Get App
	function GetApp(){
		echo $this->model->GetApp();
		die;
	}

	// save App
	function saveApp(){
		$txtAppName = $_POST['txtAppName'];
		$txtAppShortName = $_POST['txtAppShortName'];
		$txtDevelopedBy = $_POST['txtDevelopedBy'];
		$txtYearDeveloped = $_POST['txtYearDeveloped'];
		$this->model->saveApp($txtAppName,$txtAppShortName, $txtDevelopedBy, $txtYearDeveloped);
		die;
	}

	/*****************************************************************
		Levels Section
	******************************************************************/

	function levels(){

		self::pnotifyScripts();
		$this->view->angularjs = array(
							URL_DIRECTORY.'views/settings/levels/js/levels.js?v=1.1',
							JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');

		$this->view->title = "Smart Home";
		$this->view->page = "Blocks";
		$this->view->action = "Blocks";
		$this->view->render('settings/levels/index');
	}

	// Add Level
	function AddLevel(){
		$txtLevel = $_POST['txtLevel'];
		$this->model->AddLevel($txtLevel);
		die;
	}

	// Edit Level
	function EditLevel(){
		$levelID = $_POST['levelID'];
		$txtLevel = $_POST['txtLevel'];
		$this->model->EditLevel($levelID,$txtLevel);
		die;
	}

	// Delete Level
	function DeleteLevel(){
		$levelID = $_POST['levelID'];
		$this->model->DeleteLevel($levelID);
		die;
	}

	//Get All Levels
	function GetAllLevels(){
		echo $this->model->AllLevels();
		die;
	}

}
