<?php

class macros extends maincontroller{

	function __construct(){
		parent::__construct();
		$this->isLoggedIn();
		$this->LoggedInUser = session::get('UserName');
		$this->view->controller = "connected_device";
		self::pnotifyScripts();
		
		$this->view->domain_url = URL_DIRECTORY;
	}

	function index(){				
		$this->view->title = "Smart Home";
		$this->view->page = "Macros";
		$this->view->action = "light";
		$this->view->render('macros/index');
	}

	function dashboard(){
		$this->index();
	}

	function home(){
		$this->index();
	}
	
	// Load all Appliance
	function macrosDevices(){
		echo $this->model->macrosDevices();
		die;
	}
	
	function list_select(){
		$this->view->angularjs = array(
									URL_DIRECTORY.'views/macros/list_select/js/macros.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
		
		$this->view->title = "Smart Home";
		$this->view->page = "Select From List";
		$this->view->action = "light";
		$this->view->render('macros/list_select/index');
	}
	
	function category(){
		$this->view->angularjs = array(
									URL_DIRECTORY.'views/macros/category/js/category.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
		
		$this->view->title = "Smart Home";
		$this->view->page = "Select Category";
		$this->view->action = "light";
		$this->view->render('macros/category/index');
	}
	
	/**
	 *  Macros Commands
	 *	macrosStatus
	 * @param array(ints) $device_ids  is a list of all devices to either turn on / off.
	 */
	 
	function macrosTurnOn(){
		$device_ids = $_POST['device_ids'];
		echo $this->model->macrosTurnOn($this->LoggedInUser,$device_ids);
		die;
	}
	
	function macrosTurnOff(){
		$device_ids = $_POST['device_ids'];
		echo $this->model->macrosTurnOff($this->LoggedInUser,$device_ids);
		die;
	}
	
	
	function isOutSideLightsON(){
		echo $this->model->isOutSideLightsON();
		die;
	}
	
	function isInHouseLightsON(){
		echo $this->model->isInHouseLightsON();
		die;
	}
	
	function OutSideLightsEvent(){
		$chkStatus = $_POST['chkStatus'];
		echo $this->model->OutSideLightsEvent($this->LoggedInUser,$chkStatus);
		die;
	}
	
	function InHouseLightsEvent(){
		$chkStatus = $_POST['chkStatus'];
		echo $this->model->InHouseLightsEvent($this->LoggedInUser,$chkStatus);
		die;
	}
	
	/**
	 *  Macros Custom
	 *	section
	 */
	 
	 function custom(){
		$this->view->angularjs = array(
									URL_DIRECTORY.'views/macros/custom/js/custom.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
		
		$this->view->title = "Smart Home";
		$this->view->page = "Select Custom";
		$this->view->action = "Custom";
		$this->view->render('macros/custom/index');
	}
	
	function allMacros(){
		echo $this->model->allMacros();
		die;
	}
	
	function allCustomMacros(){
		echo $this->model->allCustomMacros();
		die;
	}
	
	function viewMacros($parameters){
		
		if(!empty($parameters['macID'])){
			$macros = json_decode($this->model->getMacros($parameters['macID']),true);
			if(count($macros) > 0){
				$this->view->angularjs = array(
											URL_DIRECTORY.'views/macros/editMacros/js/editMacros.js?v=1.1',
											JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
				
				$this->view->title = "Smart Home";
				$this->view->page = "Select Custom";
				$this->view->action = "Edit Custom";
				$this->view->render('macros/editMacros/index');
			}else{
				$this->nodata();
			}
		}
	}
	
	function newMacros(){
		
		$this->view->angularjs = array(
									URL_DIRECTORY.'views/macros/addMacros/js/addMacros.js?v=1.1',
									JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
		
		$this->view->title = "Smart Home";
		$this->view->page = "Select Custom";
		$this->view->action = "Add Custom";
		$this->view->render('macros/addMacros/index');
	}
	
	function getMacros(){
		$macID = $_POST['macID'];
		echo $this->model->getMacros($macID);
		die;
	}
	
	function addMacros(){
		$macName = $_POST['macName'];
		$macDescription = $_POST['macDescription'];
		echo $this->model->addMacros($macName,$macDescription);
		die;
	}
	
	function editMacros(){
		$macID = $_POST['macID'];
		$macName = $_POST['macName'];
		$macDescription = $_POST['macDescription'];
		echo $this->model->editMacros($macID,$macName,$macDescription);
		die;
	}
	
	function deleteMacros(){
		$macID = $_POST['macID'];
		echo $this->model->deleteMacros($macID);
		die;
	}
	
	function macrosList($parameters){
		
		if(!empty($parameters['macID'])){
			$macros = json_decode($this->model->getMacros($parameters['macID']),true);
			if(count($macros) > 0){
				$this->view->angularjs = array(
											URL_DIRECTORY.'views/macros/macrosList/js/macrosList.js?v=1.1',
											JS_DIRECTORY.'angular/smartHomeService.js?v=1.1');
				
				$this->view->title = "Smart Home";
				$this->view->page = "Select Custom";
				$this->view->action = "Macros List Custom";
				$this->view->render('macros/macrosList/index');
			}else{
				$this->nodata();
			}
		}
	}
	
	function allDevices(){
		echo $this->model->allDevices();
		die;
	}
	
	function allMacrosList(){
		$macID = $_POST['macID'];
		echo $this->model->allMacrosList($macID);
		die;
	}
	
	function addMacrosDevice(){
		$macID = $_POST['macID'];
		$conn_d_id = $_POST['conn_d_id'];
		echo $this->model->addMacrosDevice($macID,$conn_d_id);
		die;
	}
	
	function removeMacrosDevice(){
		$macID = $_POST['macID'];
		$conn_d_id = $_POST['conn_d_id'];
		echo $this->model->removeMacrosDevice($macID,$conn_d_id);
		die;
	}
	
	function customTurnOn(){
		$macID = $_POST['macID'];
		$state = $_POST['state'];
		echo $this->model->customTurnOn($this->LoggedInUser,$macID,$state);
		die;
	}
	
	function customTurnOff(){
		$macID = $_POST['macID'];
		$state = $_POST['state'];
		echo $this->model->customTurnOff($this->LoggedInUser,$macID,$state);
		die;
	}
}
